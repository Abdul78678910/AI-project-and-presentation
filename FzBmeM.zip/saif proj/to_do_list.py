import mysql.connector

conn = mysql.connector.connect(user='root', password='', host='localhost', database='to_do_list')


def signup(name,username,password):
    cursor = conn.cursor()
    cursor.execute("INSERT INTO members(Name, username, password) VALUES (%s,%s,%s)",(name,username,password))
    conn.commit()
    result = cursor.rowcount;
    
    return result
    
def addlist(id):
    cursor = conn.cursor()
    note=input("WRITE NOTE HERE: ")
    cursor.execute("INSERT INTO list(note, id) VALUES (%s,%s)",(note,id))
    conn.commit()
    result = cursor.rowcount;
    
    if result==0:
        input("ERROR (PRASE ENTER FOR BACK!)")
        addlist(id)
    else:
        print("SUCCESFULLY ADD NOTE!")
        input("PRASE ENTER FOR BACK!")
        to_do(id)
    
def signin(username,password):
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM members WHERE username=%s AND password=%s",(username,password))
    result = cursor.fetchall();
    # print(result)
    if(result==[]):
        return 0
    return result


def updatelist(id):
    sno=get_sno(id)
    # print(sno)
    try:
        updatesno=sno[int(input("Which one do you want to UPDATE>>: "))-1]
        massege= input("WRITE HERE>>:")
    except:
        print("WRONG INPUT!")
        updatelist(id)
    cursor = conn.cursor()
    cursor.execute("UPDATE list SET note=%s WHERE sno=%s",(massege,updatesno))
    conn.commit()
    result = cursor.rowcount;
    
    if result==0:
        input("ERROR (PRASE ENTER FOR BACK!)")
        updatelist(id)
    else:
        print("SUCCESFULLY UPDATE NOTE!")
        input("PRASE ENTER FOR BACK!")
        to_do(id)
    


def deletelist(id):
    sno=get_sno(id)
    # print(sno)
    try:
        delect=sno[int(input("Which one do you want to delect>>: "))-1]
    except:
        print("WRONG INPUT!")
        deletelist(id)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM `list` WHERE sno=%s",(delect,))
    conn.commit()
    result = cursor.rowcount;
    
    if result==0:
        input("ERROR (PRASE ENTER FOR BACK!)")
        deletelist(id)
    else:
        print("SUCCESFULLY ADD NOTE!")
        input("PRASE ENTER FOR BACK!")
        to_do(id)
    

def get_sno(id):
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM list WHERE id=%s",(id,))
    result = cursor.fetchall();
    sno = [];
    if(result==[]):
        print("EMPTY NOTE")
    else:
        for x in range(len(result)):
            print(1+x,". ",result[x][1])
            sno.append(result[x][0])
    return sno   
 
def print_list(id):
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM list WHERE id=%s",(id,))
    result = cursor.fetchall();

    if(result==[]):
        print("EMPTY NOTE")
    else:
        for x in range(len(result)):
            print(1+x,". ",result[x][1])
        input("PRASE ENTER FOR BACK!")
        to_do(id)

def updateprofile(id):
    print("==========UDATE FORM==========")
    name=input("Enter you new name: ")
    username=input("Enter you new username: ")
    password=input("Enter you new password: ")
    print("==========================")

    
    cursor = conn.cursor()
    cursor.execute("UPDATE members SET Name=%s ,username=%s ,password=%s WHERE id=%s",(name,username,password,id))
    conn.commit()
    result = cursor.rowcount;
    
    if result==0:
        print("ERROR!")
        input("PRUSE ENTER FOR BACK!")
        to_do(id)
    else:
        print("SUCCEFULLY UPDATED PROFILE!")
        input("PRUSE ENTER FOR BACK!")
        to_do(id)


def profile(id):
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM members WHERE id=%s",(id,))
    result = cursor.fetchall();
    print("ID: ",result[0][0])
    print("NAME: ",result[0][1])
    print("USERNAME: ",result[0][2])
    print("PASSWORD: ",result[0][3])
    
    try:
        p=int(input("PRASE 1 FOR UPDATE PROFILE>>: "))
    except:
        to_do(id)
    if p==1:
        updateprofile(id)
    else:
        to_do(id)

def to_do(id):
    print("==========================")
    print("(      1. CHECK LIST      )")
    print("(      2. ADD LIST        )")
    print("(      3. DELECT LIST     )")
    print("(      4. PROFILE         )")
    print("(      5. UPDATE LIST     )")
    print("(      6. LOGOUT          )")
    print("==========================")
    try:
        key=int(input(">>:"))
    except:
        print("WRONG INPUT!")
        to_do(id)
    if key==1:
        print_list(id)
    elif key==2:
        addlist(id)
    elif key==3:
        deletelist(id)
    elif key==4:
        profile(id)
    elif key==5:
        updatelist(id)
    else:
        body()
def getlist(id):
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM list WHERE id=%s",(id,))
    result = cursor.fetchall();
    # print(result)
    if(result==[]):
        return 0
    return result
def body():
    print("=========================")
    print("(        1.SINGIN        )")
    print("(        2.SINGUP        )")
    print("(         3.BACK         )")
    print("=========================")
    try:
        key=int(input(">>:"))
    except:
        print("WRONG INPUT!")
        body()
    if key==1:
        result=signin(input("Enter your username: "),input('Password:'));
        if result==0:
            print("WRONG DATA!")
            body()
        print("WELLCOME ",result[0][1])
        to_do(result[0][0])
    elif key==2:
        result= signup(input("Enter name:"),input("Enter usernanme:"),input("Enter password:"));
        print(result)
    else:
        print("By!")   
body()

        